Certificates generated for server CN 192.168.99.100 and postgres user (client side CN postgres)
On Windows files mentioned below must be located in %appdata%/postgresql/ directory; for Linux in ~/.postgresql/
* root.crt
* postgresql.crt
* postgresql.key


